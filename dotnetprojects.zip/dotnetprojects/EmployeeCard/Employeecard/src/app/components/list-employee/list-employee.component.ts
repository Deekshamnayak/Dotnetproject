import { DatePipe } from '@angular/common';

import { Component, OnInit } from '@angular/core';

import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';

import { Employee } from '../../Model/Employee';


@Component({
  selector: 'app-list-employee',
  standalone: true,
  imports: [DatePipe, CommonModule],
  templateUrl: './list-employee.component.html',
  styleUrl: './list-employee.component.css'
})
export class ListEmployeeComponent implements OnInit {
ngOnInit(): void {
  throw new Error('Method not implemented.');
}
employees:Employee[]=[{
  id:1,
  name : "Deeksha",

  gender: "Female",

  email: "Deeksha@ust",

  phoneNumber: 4444444444,

  dateOfBirth: new Date(2002),

  department: "ISE",

  isActive: true,
  photoPath:"profpicc.jpg"
 
},
{
  id:1,
  name : "Deeksha",

  gender: "Female",

  email: "Deeksha@ust",

  phoneNumber: 4444444444,

  dateOfBirth: new Date(2002),

  department: "ISE",

  isActive: true,
  photoPath:"profpicc.jpg"
 

 
}]
}
