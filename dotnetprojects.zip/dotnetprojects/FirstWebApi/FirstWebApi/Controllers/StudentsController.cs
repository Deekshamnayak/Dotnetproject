﻿using FirstWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FirstWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private static List<Students> _students = new List<Students>
        {
            new Students { Id = 1, Name = "Nitya", Marks = 100 },
            new Students { Id = 2, Name = "Deeksha", Marks = 99},
            new Students { Id = 3, Name = "Dia",Marks = 97 },
            // Add more products
        };
        // GET: api/students
        [HttpGet]
        public ActionResult<IEnumerable<Students>> GetProducts()
        {
            return _students;
        }
        // GET: api/students/2
        [HttpGet("{id}")]
        public ActionResult<Students> GetStudent(int id)
        {
            var students = _students.FirstOrDefault(p => p.Id == id);
            if (students == null)
            {
                return NotFound();
            }
            return students;
        }
        // POST: api/students
        [HttpPost]
        public ActionResult<Students> PostStudent(Students student)
        {
            _students.Add(student);
            return CreatedAtAction(nameof(GetStudent), new { id = student.Id }, student);
        }
        // PUT: api/products/5
        [HttpPut("{id}")]
        public IActionResult PutStudent(int id, Students student)
        {
            if (id != student.Id)
            {
                return BadRequest();
            }
            var existingProduct = _students.FirstOrDefault(p => p.Id == id);
            if (existingProduct == null)
            {
                return NotFound();
            }
            existingProduct.Name = student.Name;
            existingProduct.Marks = student.Marks;
           
            // In a real application, here you would update the product in the database
            return NoContent();
        }
        // DELETE: api/products/5
        [HttpDelete("{id}")]
        public IActionResult DeleteStudent(int id)
        {
            var student = _students.FirstOrDefault(p => p.Id == id);
            if (student == null)
            {
                return NotFound();
            }
            _students.Remove(student);
            // In a real application, here you would delete the product from the database
            return NoContent();
        }



    }
}
