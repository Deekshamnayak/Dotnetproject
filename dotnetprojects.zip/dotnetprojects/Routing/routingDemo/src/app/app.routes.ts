import { Routes } from '@angular/router';
import { FirstComponent } from './component/first/first.component';
import { SecondComponent } from './component/second/second.component';
import { ThirdComponent } from './component/third/third.component';
import { ChildAComponent } from './component/first/child-a/child-a.component';
import { ChildBComponent } from './component/first/child-b/child-b.component';

export const routes: Routes = [{path: 'first-component', component: FirstComponent,
children : [{path:'',redirectTo:'child-a',pathMatch:'full'},
{path: 'child-a',component: ChildAComponent},
{path: 'child-b',component:ChildBComponent}]},
{path: 'second-component', component: SecondComponent},
{path:'',redirectTo:'first-component',pathMatch:'full'},
{path: 'third-component', component: ThirdComponent}];
