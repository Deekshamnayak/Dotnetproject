import { Component } from '@angular/core';

@Component({
  selector: 'app-child-b',
  standalone: true,
  imports: [],
  templateUrl: './child-b.component.html',
  styleUrl: './child-b.component.css'
})
export class ChildBComponent {

}
