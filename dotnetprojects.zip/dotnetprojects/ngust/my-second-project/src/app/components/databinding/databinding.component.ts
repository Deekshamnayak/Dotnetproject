import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-databinding',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './databinding.component.html',
  styleUrl: './databinding.component.css'
})
export class DatabindingComponent {
  courseName: string = "Angular 18";

  //inputeType = "checkbox";
 
  inputeType = "radio";
 
  amount = 99999;
 
  city: any;
 
  stateName: string = "";
 
  currentDate: Date = new Date();
 
  isIndian: boolean = true;
 
  col = 2;
 
  myClassName: string = "bg-primary";
 
  firstName = signal("Deeksha");
  
  cunstructor()
  {
    this.city="Gokarna";
  }
  changeName() {

    this.firstName.set("Virat Kohali");
  
   }
  
   changeCourseName() {
  
    this.courseName = "React JS";
  
   }
  
   showMessage(message: string) {
  
    alert(message)
  
   }
  

}
