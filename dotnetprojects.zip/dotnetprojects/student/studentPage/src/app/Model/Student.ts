export class Student {

    id: number;
  
    name: string;
  
    gender: string;
  
    department: string;
  }
  
  