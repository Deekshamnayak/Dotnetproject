import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { StudentmenuComponent } from "./component/studentmenu/studentmenu.component";
import { AddStudentComponent } from './component/studentmenu/add-student/add-student.component';
import { DeleteStudentComponent } from './component/studentmenu/delete-student/delete-student.component';
import { StudentDetailsComponent } from './component/studentmenu/student-details/student-details.component';
import { StudentListComponent } from './component/studentmenu/student-list/student-list.component';
import { UpdateStudentComponent } from './component/studentmenu/update-student/update-student.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, StudentmenuComponent,RouterLink,AddStudentComponent,DeleteStudentComponent,StudentDetailsComponent,StudentListComponent,UpdateStudentComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'studentPage';
}
