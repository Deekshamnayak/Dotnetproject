import { Routes } from '@angular/router';
import { StudentmenuComponent } from './component/studentmenu/studentmenu.component';
import { AddStudentComponent } from './component/studentmenu/add-student/add-student.component';
import { DeleteStudentComponent } from './component/studentmenu/delete-student/delete-student.component';
import { StudentDetailsComponent } from './component/studentmenu/student-details/student-details.component';
import { UpdateStudentComponent } from './component/studentmenu/update-student/update-student.component';
import { StudentListComponent } from './component/studentmenu/student-list/student-list.component';


export const routes: Routes = [{path: 'studentmenu',component: StudentmenuComponent},
{path:'',redirectTo:'student-list',pathMatch:'full'},
{path: 'add-student',component: AddStudentComponent},
{path: 'delete-student',component: DeleteStudentComponent},
{path: 'student-details',component: StudentDetailsComponent},
{path: 'update-student',component: UpdateStudentComponent},
{path: 'student-list',component: StudentListComponent}

];
