import { Component } from '@angular/core';
import { Student } from '../../../Model/Student';
import { compileNgModule } from '@angular/compiler';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css'
})
export class StudentListComponent {
  st: Student[] =[{
    id:1,
    name :"Nitya",
    gender :"Female",
    department:"ISE"
  },
  {
    id:2,
    name :"Divya",
    gender :"Female",
    department:"CSE"
  }]


}
