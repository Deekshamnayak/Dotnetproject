import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AddStudentComponent } from './add-student/add-student.component';
import { DeleteStudentComponent } from './delete-student/delete-student.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { StudentListComponent } from './student-list/student-list.component';
import { UpdateStudentComponent } from './update-student/update-student.component';


@Component({
  selector: 'app-studentmenu',
  standalone: true,
  imports: [RouterLink,RouterOutlet,AddStudentComponent,DeleteStudentComponent,StudentDetailsComponent,StudentListComponent,UpdateStudentComponent],
  templateUrl: './studentmenu.component.html',
  styleUrl: './studentmenu.component.css'
})
export class StudentmenuComponent {

}
