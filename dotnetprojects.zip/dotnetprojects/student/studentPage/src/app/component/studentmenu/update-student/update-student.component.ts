import { Component } from '@angular/core';

@Component({
  selector: 'app-update-student',
  standalone: true,
  imports: [],
  templateUrl: './update-student.component.html',
  styleUrl: './update-student.component.css'
})
export class UpdateStudentComponent {

}
